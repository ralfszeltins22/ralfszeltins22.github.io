(function () {
  'use strict';

  var PROXY_ORIGIN = 'https://z-klase.ddns.net';
  var REAL_ORIGIN = 'https://family.e-klase.lv';

  function rewriteUrl(input) {
    if (typeof input !== 'string' || input.length === 0) return input;

    var absolute;
    try {
      absolute = new URL(input, window.location.href);
    } catch (e) {
      return input;
    }

    if (absolute.origin !== REAL_ORIGIN) return input;

    var isApi = absolute.pathname === '/api' || absolute.pathname.indexOf('/api/') === 0;
    var isAssets = absolute.pathname === '/assets' || absolute.pathname.indexOf('/assets/') === 0;
    if (!isApi && !isAssets) return input;

    return PROXY_ORIGIN + absolute.pathname + absolute.search + absolute.hash;
  }

  var originalFetch = window.fetch;
  window.fetch = function (input, init) {
    if (typeof input === 'string') {
      var rewritten = rewriteUrl(input);
      return originalFetch.call(this, rewritten, init);
    }

    if (input instanceof Request) {
      var rewrittenUrl = rewriteUrl(input.url);
      if (rewrittenUrl !== input.url) {
        var newRequest = new Request(rewrittenUrl, input);
        return originalFetch.call(this, newRequest, init);
      }
      return originalFetch.call(this, input, init);
    }

    return originalFetch.call(this, input, init);
  };

  var originalOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    var rewrittenUrl = rewriteUrl(url);
    var args = Array.prototype.slice.call(arguments);
    args[1] = rewrittenUrl;
    return originalOpen.apply(this, args);
  };

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register = function () {
      return Promise.reject(new Error('Service worker registration blocked by Z-Klase.'));
    };

    navigator.serviceWorker.getRegistrations().then(function (registrations) {
      registrations.forEach(function (registration) {
        registration.unregister();
      });
    }).catch(function () {});
  }

})();
