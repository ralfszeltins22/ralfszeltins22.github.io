# Z-Klase — Chrome paplašinājums

Šis paplašinājums nav publicēts Chrome Web Store, tāpēc tas jāielādē
manuāli izstrādātāja režīmā ("Developer mode").

## Uzstādīšana

1. Izsaiņo šo `.zip` failu jebkurā mapē (piemēram, `z-klase-extension`).
2. Chrome adrešu joslā atver `chrome://extensions`.
3. Augšējā labajā stūrī ieslēdz **Developer mode**.
4. Klikšķini **Load unpacked** un izvēlies izsaiņoto `z-klase-extension` mapi.
5. Rīkjoslā parādīsies zilā "Z" ikona.

## Lietošana

- **Klikšķis uz ikonas** — atver `family.e-klase.lv` jaunā cieltā.
- **Labais klikšķis uz ikonas** — parāda opciju **"Atspējot Z-Klase"**
  / **"Iespējot Z-Klase"**. Šī opcija izslēdz/ieslēdz tikai pieprasījumu
  novirzīšanu uz proxy (`/api` un `/assets`) — pati ikona un iespēja
  atvērt e-klasi paliek aktīva. Kad novirzīšana ir izslēgta, ikona kļūst
  pelēka un uz tās parādās sarkans "OFF" indikators.
- Pārslēdzot stāvokli, jebkuras jau atvērtas `family.e-klase.lv` cilnes
  automātiski tiek pārlādētas, lai izmaiņas stātos spēkā uzreiz.

## Ja maina proxy adresi

Proxy servera adrese (`https://z-klase.ddns.net`) ir norādīta failā
`scripts/main-world.js`, mainīgajā `PROXY_ORIGIN`. Pēc izmaiņām
paplašinājums jāpārlādē no `chrome://extensions` lapas (pogas ar apļveida
bultiņu).

## Publicēšana Chrome Web Store

Kods un ikonas ir gatavas augšupielādei, bet pašā Chrome Web Store
izstrādātāju panelī (https://chrome.google.com/webstore/devconsole)
papildus vēl jāaizpilda:

1. **Vienreizēja izstrādātāja reģistrācijas maksa** (~$5, Google konts).
2. **Privātuma politika (Privacy Policy URL)** — obligāta, jo
   paplašinājums piekļūst `family.e-klase.lv` datiem (potenciāli skolēnu
   personas datiem) un pārsūta pieprasījumus uz trešo pusi (tavu proxy).
   Bez šī saite izstrādātāju panelī paplašinājumu nepublicēs.
3. **"Privacy practices" cilne** — jānorāda, kādus datus paplašinājums
   apstrādā (šajā gadījumā: autentifikācijas/sesijas dati un skolas
   informācija, kas tiek novirzīta uz `z-klase.ddns.net`).
4. **Vismaz 1 ekrānuzņēmums** (1280×800 vai 640×400) paplašinājuma
   darbībai listingā.
5. **Single purpose apraksts** — īss paskaidrojums pārskatītājiem, kāpēc
   paplašinājumam vajadzīga piekļuve tieši `family.e-klase.lv`.

Ja paplašinājums paredzēts tikai savai/ģimenes lietošanai, nevis plašai
publikai, to var publicēt arī kā **Unlisted** (redzams tikai pa tiešo
saiti, neparādās meklēšanā) — tad prasības ir tās pašas, bet izplatīšana
ir ierobežota.

## Faili

- `manifest.json` — paplašinājuma konfigurācija (Manifest V3).
- `background.js` — apstrādā ikonas klikšķi, labā klikšķa izvēlni un
  ieslēdz/izslēdz pieprasījumu novirzīšanas skriptu.
- `scripts/main-world.js` — oriģinālā userscript loģika (fetch/XHR
  pārrakstīšana + Service Worker bloķēšana), palaista lapas pašas JS
  kontekstā ("MAIN world"), lai tā spētu ietekmēt Flutter lietotnes
  pieprasījumus.
- `icons/` — rīkjoslas ikonas (aktīvs/izslēgts stāvoklis, 16/32/48/128px).
