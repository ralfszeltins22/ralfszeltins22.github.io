const REAL_URL = 'https://family.e-klase.lv/';
const STORAGE_KEY = 'zklaseEnabled';
const CONTENT_SCRIPT_ID = 'zklase-proxy-main-world';
const MENU_ID = 'zklase-toggle-enabled';
const REDIRECT_MATCH = 'https://family.e-klase.lv/*';

const ICONS_ENABLED = {
  16: 'icons/icon16.png',
  32: 'icons/icon32.png',
  48: 'icons/icon48.png',
  128: 'icons/icon128.png'
};

const ICONS_DISABLED = {
  16: 'icons/icon16-disabled.png',
  32: 'icons/icon32-disabled.png',
  48: 'icons/icon48-disabled.png',
  128: 'icons/icon128-disabled.png'
};

async function getEnabledState() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  return stored[STORAGE_KEY] !== false;
}

async function setEnabledState(enabled) {
  await chrome.storage.local.set({ [STORAGE_KEY]: enabled });
}

async function syncContentScriptRegistration(enabled) {
  const existing = await chrome.scripting.getRegisteredContentScripts({
    ids: [CONTENT_SCRIPT_ID]
  });
  const isRegistered = existing.length > 0;

  if (enabled && !isRegistered) {
    await chrome.scripting.registerContentScripts([
      {
        id: CONTENT_SCRIPT_ID,
        matches: [REDIRECT_MATCH],
        js: ['scripts/main-world.js'],
        runAt: 'document_start',
        world: 'MAIN',
        allFrames: true,
        persistAcrossSessions: true
      }
    ]);
  } else if (!enabled && isRegistered) {
    await chrome.scripting.unregisterContentScripts({
      ids: [CONTENT_SCRIPT_ID]
    });
  }
}

async function refreshUi(enabled) {
  await chrome.action.setIcon({ path: enabled ? ICONS_ENABLED : ICONS_DISABLED });

  await chrome.action.setTitle({
    title: enabled
      ? 'Z-Klase (aktīvs) — klikšķis atver E-klasi'
      : 'Z-Klase (izslēgts) — klikšķis atver E-klasi'
  });

  if (enabled) {
    await chrome.action.setBadgeText({ text: '' });
  } else {
    await chrome.action.setBadgeBackgroundColor({ color: '#FFFFFF' });
    await chrome.action.setBadgeTextColor({ color: '#D93025' });
    await chrome.action.setBadgeText({ text: 'OFF' });
  }

  await chrome.contextMenus.update(MENU_ID, {
    title: enabled ? 'Atspējot Z-Klase' : 'Iespējot Z-Klase'
  });
}

async function reloadEklaseTabs() {
  const tabs = await chrome.tabs.query({ url: REDIRECT_MATCH });
  for (const tab of tabs) {
    if (typeof tab.id === 'number') {
      chrome.tabs.reload(tab.id);
    }
  }
}

async function initialize() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  if (stored[STORAGE_KEY] === undefined) {
    await setEnabledState(true);
  }

  const enabled = await getEnabledState();
  await syncContentScriptRegistration(enabled);
  await refreshUi(enabled);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: 'Atspējot Z-Klase',
    contexts: ['action']
  });
  initialize();
});

chrome.runtime.onStartup.addListener(() => {
  initialize();
});

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: REAL_URL });
});

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== MENU_ID) return;

  const current = await getEnabledState();
  const next = !current;
  await setEnabledState(next);
  await syncContentScriptRegistration(next);
  await refreshUi(next);
  await reloadEklaseTabs();
});
